// jQuery(document).ready(function (e) {
//   "use strict";
//   e(function () {
//     e("#contact").validate({
//       rules: {
//         name: {
//           required: !0,
//           minlength: 2
//         },
//         surname: {
//           required: !0,
//           minlength: 2
//         },
//         email: {
//           required: !0,
//           email: !0
//         },
//         message: {
//           required: !0
//         }
//       },
//       messages: {
//         name: {
//           required: "Please type your name",
//           minlength: "Please type your name correctly"
//         },
//         surname: {
//           required: "Please type your surname",
//           minlength: "Please type your surname correctly"
//         },
//         email: {
//           required: "Please type your e-mail correctly"
//         },
//         message: {
//           required: "Please type your message",
//           minlength: "To short message"
//         }
//       },
//       submitHandler: function (r) {
//         e(r).ajaxSubmit({
//           type: "POST",
//           data: e(r).serialize(),
//           url: "/php/process.php",
//           success: function () {
//             e("#contact :input").attr("disabled", "disabled"), e("#contact").fadeTo("slow", 0, function () {
//               e(this).find(":input").attr("disabled", "disabled"), e(this).find("label").css("cursor", "default"), e("#success").fadeIn()
//             })
//           },
//           error: function () {
//             e("#contact").fadeTo("slow", 1, function () {
//               e("#error").fadeIn()
//             })
//           }
//         })
//       }
//     })
//   })
// });


// ! function (e) {
//   "use strict";
//   var t = {};
//   t.fileapi = void 0 !== e("<input type='file'/>").get(0).files, t.formdata = void 0 !== window.FormData;
//   var r = !!e.fn.prop;

//   function a(t) {
//     var r = t.data;
//     t.isDefaultPrevented() || (t.preventDefault(), e(this).ajaxSubmit(r))
//   }

//   function n(t) {
//     var r = t.target,
//       a = e(r);
//     if (!a.is("[type=submit],[type=image]")) {
//       var n = a.closest("[type=submit]");
//       if (0 === n.length) return;
//       r = n[0]
//     }
//     var i = this;
//     if (i.clk = r, "image" == r.type)
//       if (void 0 !== t.offsetX) i.clk_x = t.offsetX, i.clk_y = t.offsetY;
//       else if ("function" == typeof e.fn.offset) {
//       var o = a.offset();
//       i.clk_x = t.pageX - o.left, i.clk_y = t.pageY - o.top
//     } else i.clk_x = t.pageX - r.offsetLeft, i.clk_y = t.pageY - r.offsetTop;
//     setTimeout(function () {
//       i.clk = i.clk_x = i.clk_y = null
//     }, 100)
//   }

//   function i() {
//     if (e.fn.ajaxSubmit.debug) {
//       var t = "[jquery.form] " + Array.prototype.join.call(arguments, "");
//       window.console && window.console.log ? window.console.log(t) : window.opera && window.opera.postError && window.opera.postError(t)
//     }
//   }
//   e.fn.attr2 = function () {
//     if (!r) return this.attr.apply(this, arguments);
//     var e = this.prop.apply(this, arguments);
//     return e && e.jquery || "string" == typeof e ? e : this.attr.apply(this, arguments)
//   }, e.fn.ajaxSubmit = function (a) {
//     if (!this.length) return i("ajaxSubmit: skipping submit process - no element selected"), this;
//     var n, o, s, u = this;
//     "function" == typeof a && (a = {
//       success: a
//     }), n = this.attr2("method"), (s = (s = "string" == typeof (o = this.attr2("action")) ? e.trim(o) : "") || window.location.href || "") && (s = (s.match(/^([^#]+)/) || [])[1]), a = e.extend(!0, {
//       url: s,
//       success: e.ajaxSettings.success,
//       type: n || "GET",
//       iframeSrc: /^https/i.test(window.location.href || "") ? "javascript:false" : "about:blank"
//     }, a);
//     var l = {};
//     if (this.trigger("form-pre-serialize", [this, a, l]), l.veto) return i("ajaxSubmit: submit vetoed via form-pre-serialize trigger"), this;
//     if (a.beforeSerialize && !1 === a.beforeSerialize(this, a)) return i("ajaxSubmit: submit aborted via beforeSerialize callback"), this;
//     var c = a.traditional;
//     void 0 === c && (c = e.ajaxSettings.traditional);
//     var f, m = [],
//       d = this.formToArray(a.semantic, m);
//     if (a.data && (a.extraData = a.data, f = e.param(a.data, c)), a.beforeSubmit && !1 === a.beforeSubmit(d, this, a)) return i("ajaxSubmit: submit aborted via beforeSubmit callback"), this;
//     if (this.trigger("form-submit-validate", [d, this, a, l]), l.veto) return i("ajaxSubmit: submit vetoed via form-submit-validate trigger"), this;
//     var p = e.param(d, c);
//     f && (p = p ? p + "&" + f : f), "GET" == a.type.toUpperCase() ? (a.url += (a.url.indexOf("?") >= 0 ? "&" : "?") + p, a.data = null) : a.data = p;
//     var h = [];
//     if (a.resetForm && h.push(function () {
//         u.resetForm()
//       }), a.clearForm && h.push(function () {
//         u.clearForm(a.includeHidden)
//       }), !a.dataType && a.target) {
//       var v = a.success || function () {};
//       h.push(function (t) {
//         var r = a.replaceTarget ? "replaceWith" : "html";
//         e(a.target)[r](t).each(v, arguments)
//       })
//     } else a.success && h.push(a.success);
//     a.success = function (e, t, r) {
//       for (var n = a.context || this, i = 0, o = h.length; i < o; i++) h[i].apply(n, [e, t, r || u, u])
//     };
//     var g = e('input[type=file]:enabled[value!=""]', this).length > 0,
//       x = "multipart/form-data",
//       b = u.attr("enctype") == x || u.attr("encoding") == x,
//       y = t.fileapi && t.formdata;
//     i("fileAPI :" + y);
//     var T, j = (g || b) && !y;
//     !1 !== a.iframe && (a.iframe || j) ? a.closeKeepAlive ? e.get(a.closeKeepAlive, function () {
//       T = S(d)
//     }) : T = S(d) : T = (g || b) && y ? function (t) {
//       for (var r = new FormData, i = 0; i < t.length; i++) r.append(t[i].name, t[i].value);
//       if (a.extraData) {
//         var o = function (t) {
//           var r, a, n = e.param(t).split("&"),
//             i = n.length,
//             o = [];
//           for (r = 0; r < i; r++) n[r] = n[r].replace(/\+/g, " "), a = n[r].split("="), o.push([decodeURIComponent(a[0]), decodeURIComponent(a[1])]);
//           return o
//         }(a.extraData);
//         for (i = 0; i < o.length; i++) o[i] && r.append(o[i][0], o[i][1])
//       }
//       a.data = null;
//       var s = e.extend(!0, {}, e.ajaxSettings, a, {
//         contentType: !1,
//         processData: !1,
//         cache: !1,
//         type: n || "POST"
//       });
//       a.uploadProgress && (s.xhr = function () {
//         var e = jQuery.ajaxSettings.xhr();
//         return e.upload && e.upload.addEventListener("progress", function (e) {
//           var t = 0,
//             r = e.loaded || e.position,
//             n = e.total;
//           e.lengthComputable && (t = Math.ceil(r / n * 100)), a.uploadProgress(e, r, n, t)
//         }, !1), e
//       });
//       s.data = null;
//       var u = s.beforeSend;
//       return s.beforeSend = function (e, t) {
//         t.data = r, u && u.call(this, e, t)
//       }, e.ajax(s)
//     }(d) : e.ajax(a), u.removeData("jqxhr").data("jqxhr", T);
//     for (var w = 0; w < m.length; w++) m[w] = null;
//     return this.trigger("form-submit-notify", [this, a]), this;

//     function S(t) {
//       var o, s, l, c, f, d, p, h, v, g, x, b, y = u[0],
//         T = e.Deferred();
//       if (t)
//         for (s = 0; s < m.length; s++) o = e(m[s]), r ? o.prop("disabled", !1) : o.removeAttr("disabled");
//       if ((l = e.extend(!0, {}, e.ajaxSettings, a)).context = l.context || l, f = "jqFormIO" + (new Date).getTime(), l.iframeTarget ? (g = (d = e(l.iframeTarget)).attr2("name")) ? f = g : d.attr2("name", f) : (d = e('<iframe name="' + f + '" src="' + l.iframeSrc + '" />')).css({
//           position: "absolute",
//           top: "-1000px",
//           left: "-1000px"
//         }), p = d[0], h = {
//           aborted: 0,
//           responseText: null,
//           responseXML: null,
//           status: 0,
//           statusText: "n/a",
//           getAllResponseHeaders: function () {},
//           getResponseHeader: function () {},
//           setRequestHeader: function () {},
//           abort: function (t) {
//             var r = "timeout" === t ? "timeout" : "aborted";
//             i("aborting upload... " + r), this.aborted = 1;
//             try {
//               p.contentWindow.document.execCommand && p.contentWindow.document.execCommand("Stop")
//             } catch (e) {}
//             d.attr("src", l.iframeSrc), h.error = r, l.error && l.error.call(l.context, h, r, t), c && e.event.trigger("ajaxError", [h, l, r]), l.complete && l.complete.call(l.context, h, r)
//           }
//         }, (c = l.global) && 0 == e.active++ && e.event.trigger("ajaxStart"), c && e.event.trigger("ajaxSend", [h, l]), l.beforeSend && !1 === l.beforeSend.call(l.context, h, l)) return l.global && e.active--, T.reject(), T;
//       if (h.aborted) return T.reject(), T;
//       (v = y.clk) && (g = v.name) && !v.disabled && (l.extraData = l.extraData || {}, l.extraData[g] = v.value, "image" == v.type && (l.extraData[g + ".x"] = y.clk_x, l.extraData[g + ".y"] = y.clk_y));
//       var j = 1,
//         w = 2;

//       function S(e) {
//         var t = null;
//         try {
//           e.contentWindow && (t = e.contentWindow.document)
//         } catch (e) {
//           i("cannot get iframe.contentWindow document: " + e)
//         }
//         if (t) return t;
//         try {
//           t = e.contentDocument ? e.contentDocument : e.document
//         } catch (r) {
//           i("cannot get iframe.contentDocument: " + r), t = e.document
//         }
//         return t
//       }
//       var k = e("meta[name=csrf-token]").attr("content"),
//         D = e("meta[name=csrf-param]").attr("content");

//       function A() {
//         var t = u.attr2("target"),
//           r = u.attr2("action");
//         y.setAttribute("target", f), n || y.setAttribute("method", "POST"), r != l.url && y.setAttribute("action", l.url), l.skipEncodingOverride || n && !/post/i.test(n) || u.attr({
//           encoding: "multipart/form-data",
//           enctype: "multipart/form-data"
//         }), l.timeout && (b = setTimeout(function () {
//           x = !0, O(j)
//         }, l.timeout));
//         var a = [];
//         try {
//           if (l.extraData)
//             for (var o in l.extraData) l.extraData.hasOwnProperty(o) && (e.isPlainObject(l.extraData[o]) && l.extraData[o].hasOwnProperty("name") && l.extraData[o].hasOwnProperty("value") ? a.push(e('<input type="hidden" name="' + l.extraData[o].name + '">').val(l.extraData[o].value).appendTo(y)[0]) : a.push(e('<input type="hidden" name="' + o + '">').val(l.extraData[o]).appendTo(y)[0]));
//           l.iframeTarget || (d.appendTo("body"), p.attachEvent ? p.attachEvent("onload", O) : p.addEventListener("load", O, !1)), setTimeout(function e() {
//             try {
//               var t = S(p).readyState;
//               i("state = " + t), t && "uninitialized" == t.toLowerCase() && setTimeout(e, 50)
//             } catch (e) {
//               i("Server abort: ", e, " (", e.name, ")"), O(w), b && clearTimeout(b), b = void 0
//             }
//           }, 15);
//           try {
//             y.submit()
//           } catch (e) {
//             document.createElement("form").submit.apply(y)
//           }
//         } finally {
//           y.setAttribute("action", r), t ? y.setAttribute("target", t) : u.removeAttr("target"), e(a).remove()
//         }
//       }
//       D && k && (l.extraData = l.extraData || {}, l.extraData[D] = k), l.forceSync ? A() : setTimeout(A, 10);
//       var E, L, M, F = 50;

//       function O(t) {
//         if (!h.aborted && !M) {
//           if ((L = S(p)) || (i("cannot access response document"), t = w), t === j && h) return h.abort("timeout"), void T.reject(h, "timeout");
//           if (t == w && h) return h.abort("server abort"), void T.reject(h, "error", "server abort");
//           if (L && L.location.href != l.iframeSrc || x) {
//             p.detachEvent ? p.detachEvent("onload", O) : p.removeEventListener("load", O, !1);
//             var r, a = "success";
//             try {
//               if (x) throw "timeout";
//               var n = "xml" == l.dataType || L.XMLDocument || e.isXMLDoc(L);
//               if (i("isXml=" + n), !n && window.opera && (null === L.body || !L.body.innerHTML) && --F) return i("requeing onLoad callback, DOM not available"), void setTimeout(O, 250);
//               var o = L.body ? L.body : L.documentElement;
//               h.responseText = o ? o.innerHTML : null, h.responseXML = L.XMLDocument ? L.XMLDocument : L, n && (l.dataType = "xml"), h.getResponseHeader = function (e) {
//                 return {
//                   "content-type": l.dataType
//                 } [e]
//               }, o && (h.status = Number(o.getAttribute("status")) || h.status, h.statusText = o.getAttribute("statusText") || h.statusText);
//               var s = (l.dataType || "").toLowerCase(),
//                 u = /(json|script|text)/.test(s);
//               if (u || l.textarea) {
//                 var f = L.getElementsByTagName("textarea")[0];
//                 if (f) h.responseText = f.value, h.status = Number(f.getAttribute("status")) || h.status, h.statusText = f.getAttribute("statusText") || h.statusText;
//                 else if (u) {
//                   var m = L.getElementsByTagName("pre")[0],
//                     v = L.getElementsByTagName("body")[0];
//                   m ? h.responseText = m.textContent ? m.textContent : m.innerText : v && (h.responseText = v.textContent ? v.textContent : v.innerText)
//                 }
//               } else "xml" == s && !h.responseXML && h.responseText && (h.responseXML = X(h.responseText));
//               try {
//                 E = _(h, s, l)
//               } catch (e) {
//                 a = "parsererror", h.error = r = e || a
//               }
//             } catch (e) {
//               i("error caught: ", e), a = "error", h.error = r = e || a
//             }
//             h.aborted && (i("upload aborted"), a = null), h.status && (a = h.status >= 200 && h.status < 300 || 304 === h.status ? "success" : "error"), "success" === a ? (l.success && l.success.call(l.context, E, "success", h), T.resolve(h.responseText, "success", h), c && e.event.trigger("ajaxSuccess", [h, l])) : a && (void 0 === r && (r = h.statusText), l.error && l.error.call(l.context, h, a, r), T.reject(h, "error", r), c && e.event.trigger("ajaxError", [h, l, r])), c && e.event.trigger("ajaxComplete", [h, l]), c && !--e.active && e.event.trigger("ajaxStop"), l.complete && l.complete.call(l.context, h, a), M = !0, l.timeout && clearTimeout(b), setTimeout(function () {
//               l.iframeTarget || d.remove(), h.responseXML = null
//             }, 100)
//           }
//         }
//       }
//       var X = e.parseXML || function (e, t) {
//           return window.ActiveXObject ? ((t = new ActiveXObject("Microsoft.XMLDOM")).async = "false", t.loadXML(e)) : t = (new DOMParser).parseFromString(e, "text/xml"), t && t.documentElement && "parsererror" != t.documentElement.nodeName ? t : null
//         },
//         C = e.parseJSON || function (e) {
//           return window.eval("(" + e + ")")
//         },
//         _ = function (t, r, a) {
//           var n = t.getResponseHeader("content-type") || "",
//             i = "xml" === r || !r && n.indexOf("xml") >= 0,
//             o = i ? t.responseXML : t.responseText;
//           return i && "parsererror" === o.documentElement.nodeName && e.error && e.error("parsererror"), a && a.dataFilter && (o = a.dataFilter(o, r)), "string" == typeof o && ("json" === r || !r && n.indexOf("json") >= 0 ? o = C(o) : ("script" === r || !r && n.indexOf("javascript") >= 0) && e.globalEval(o)), o
//         };
//       return T
//     }
//   }, e.fn.ajaxForm = function (t) {
//     if ((t = t || {}).delegation = t.delegation && e.isFunction(e.fn.on), !t.delegation && 0 === this.length) {
//       var r = {
//         s: this.selector,
//         c: this.context
//       };
//       return !e.isReady && r.s ? (i("DOM not ready, queuing ajaxForm"), e(function () {
//         e(r.s, r.c).ajaxForm(t)
//       }), this) : (i("terminating; zero elements found by selector" + (e.isReady ? "" : " (DOM not ready)")), this)
//     }
//     return t.delegation ? (e(document).off("submit.form-plugin", this.selector, a).off("click.form-plugin", this.selector, n).on("submit.form-plugin", this.selector, t, a).on("click.form-plugin", this.selector, t, n), this) : this.ajaxFormUnbind().bind("submit.form-plugin", t, a).bind("click.form-plugin", t, n)
//   }, e.fn.ajaxFormUnbind = function () {
//     return this.unbind("submit.form-plugin click.form-plugin")
//   }, e.fn.formToArray = function (r, a) {
//     var n = [];
//     if (0 === this.length) return n;
//     var i, o, s, u, l, c, f, m = this[0],
//       d = r ? m.getElementsByTagName("*") : m.elements;
//     if (!d) return n;
//     for (i = 0, c = d.length; i < c; i++)
//       if ((s = (l = d[i]).name) && !l.disabled)
//         if (r && m.clk && "image" == l.type) m.clk == l && (n.push({
//           name: s,
//           value: e(l).val(),
//           type: l.type
//         }), n.push({
//           name: s + ".x",
//           value: m.clk_x
//         }, {
//           name: s + ".y",
//           value: m.clk_y
//         }));
//         else if ((u = e.fieldValue(l, !0)) && u.constructor == Array)
//       for (a && a.push(l), o = 0, f = u.length; o < f; o++) n.push({
//         name: s,
//         value: u[o]
//       });
//     else if (t.fileapi && "file" == l.type) {
//       a && a.push(l);
//       var p = l.files;
//       if (p.length)
//         for (o = 0; o < p.length; o++) n.push({
//           name: s,
//           value: p[o],
//           type: l.type
//         });
//       else n.push({
//         name: s,
//         value: "",
//         type: l.type
//       })
//     } else null !== u && void 0 !== u && (a && a.push(l), n.push({
//       name: s,
//       value: u,
//       type: l.type,
//       required: l.required
//     }));
//     if (!r && m.clk) {
//       var h = e(m.clk),
//         v = h[0];
//       (s = v.name) && !v.disabled && "image" == v.type && (n.push({
//         name: s,
//         value: h.val()
//       }), n.push({
//         name: s + ".x",
//         value: m.clk_x
//       }, {
//         name: s + ".y",
//         value: m.clk_y
//       }))
//     }
//     return n
//   }, e.fn.formSerialize = function (t) {
//     return e.param(this.formToArray(t))
//   }, e.fn.fieldSerialize = function (t) {
//     var r = [];
//     return this.each(function () {
//       var a = this.name;
//       if (a) {
//         var n = e.fieldValue(this, t);
//         if (n && n.constructor == Array)
//           for (var i = 0, o = n.length; i < o; i++) r.push({
//             name: a,
//             value: n[i]
//           });
//         else null !== n && void 0 !== n && r.push({
//           name: this.name,
//           value: n
//         })
//       }
//     }), e.param(r)
//   }, e.fn.fieldValue = function (t) {
//     for (var r = [], a = 0, n = this.length; a < n; a++) {
//       var i = this[a],
//         o = e.fieldValue(i, t);
//       null === o || void 0 === o || o.constructor == Array && !o.length || (o.constructor == Array ? e.merge(r, o) : r.push(o))
//     }
//     return r
//   }, e.fieldValue = function (t, r) {
//     var a = t.name,
//       n = t.type,
//       i = t.tagName.toLowerCase();
//     if (void 0 === r && (r = !0), r && (!a || t.disabled || "reset" == n || "button" == n || ("checkbox" == n || "radio" == n) && !t.checked || ("submit" == n || "image" == n) && t.form && t.form.clk != t || "select" == i && -1 == t.selectedIndex)) return null;
//     if ("select" == i) {
//       var o = t.selectedIndex;
//       if (o < 0) return null;
//       for (var s = [], u = t.options, l = "select-one" == n, c = l ? o + 1 : u.length, f = l ? o : 0; f < c; f++) {
//         var m = u[f];
//         if (m.selected) {
//           var d = m.value;
//           if (d || (d = m.attributes && m.attributes.value && !m.attributes.value.specified ? m.text : m.value), l) return d;
//           s.push(d)
//         }
//       }
//       return s
//     }
//     return e(t).val()
//   }, e.fn.clearForm = function (t) {
//     return this.each(function () {
//       e("input,select,textarea", this).clearFields(t)
//     })
//   }, e.fn.clearFields = e.fn.clearInputs = function (t) {
//     var r = /^(?:color|date|datetime|email|month|number|password|range|search|tel|text|time|url|week)$/i;
//     return this.each(function () {
//       var a = this.type,
//         n = this.tagName.toLowerCase();
//       r.test(a) || "textarea" == n ? this.value = "" : "checkbox" == a || "radio" == a ? this.checked = !1 : "select" == n ? this.selectedIndex = -1 : "file" == a ? /MSIE/.test(navigator.userAgent) ? e(this).replaceWith(e(this).clone(!0)) : e(this).val("") : t && (!0 === t && /hidden/.test(a) || "string" == typeof t && e(this).is(t)) && (this.value = "")
//     })
//   }, e.fn.resetForm = function () {
//     return this.each(function () {
//       ("function" == typeof this.reset || "object" == typeof this.reset && !this.reset.nodeType) && this.reset()
//     })
//   }, e.fn.enable = function (e) {
//     return void 0 === e && (e = !0), this.each(function () {
//       this.disabled = !e
//     })
//   }, e.fn.selected = function (t) {
//     return void 0 === t && (t = !0), this.each(function () {
//       var r = this.type;
//       if ("checkbox" == r || "radio" == r) this.checked = t;
//       else if ("option" == this.tagName.toLowerCase()) {
//         var a = e(this).parent("select");
//         t && a[0] && "select-one" == a[0].type && a.find("option").selected(!1), this.selected = t
//       }
//     })
//   }, e.fn.ajaxSubmit.debug = !1
// }(jQuery);


// /*! jQuery Validation Plugin - v1.11.1 - 3/22/2013\n* https://github.com/jzaefferer/jquery-validation
//  * Copyright (c) 2013 Jörn Zaefferer; Licensed MIT */
// (function (t) {
//   t.extend(t.fn, {
//     validate: function (e) {
//       if (!this.length) return e && e.debug && window.console && console.warn("Nothing selected, can't validate, returning nothing."), void 0;
//       var i = t.data(this[0], "validator");
//       return i ? i : (this.attr("novalidate", "novalidate"), i = new t.validator(e, this[0]), t.data(this[0], "validator", i), i.settings.onsubmit && (this.validateDelegate(":submit", "click", function (e) {
//         i.settings.submitHandler && (i.submitButton = e.target), t(e.target).hasClass("cancel") && (i.cancelSubmit = !0), void 0 !== t(e.target).attr("formnovalidate") && (i.cancelSubmit = !0)
//       }), this.submit(function (e) {
//         function s() {
//           var s;
//           return i.settings.submitHandler ? (i.submitButton && (s = t("<input type='hidden'/>").attr("name", i.submitButton.name).val(t(i.submitButton).val()).appendTo(i.currentForm)), i.settings.submitHandler.call(i, i.currentForm, e), i.submitButton && s.remove(), !1) : !0
//         }
//         return i.settings.debug && e.preventDefault(), i.cancelSubmit ? (i.cancelSubmit = !1, s()) : i.form() ? i.pendingRequest ? (i.formSubmitted = !0, !1) : s() : (i.focusInvalid(), !1)
//       })), i)
//     },
//     valid: function () {
//       if (t(this[0]).is("form")) return this.validate().form();
//       var e = !0,
//         i = t(this[0].form).validate();
//       return this.each(function () {
//         e = e && i.element(this)
//       }), e
//     },
//     removeAttrs: function (e) {
//       var i = {},
//         s = this;
//       return t.each(e.split(/\s/), function (t, e) {
//         i[e] = s.attr(e), s.removeAttr(e)
//       }), i
//     },
//     rules: function (e, i) {
//       var s = this[0];
//       if (e) {
//         var r = t.data(s.form, "validator").settings,
//           n = r.rules,
//           a = t.validator.staticRules(s);
//         switch (e) {
//           case "add":
//             t.extend(a, t.validator.normalizeRule(i)), delete a.messages, n[s.name] = a, i.messages && (r.messages[s.name] = t.extend(r.messages[s.name], i.messages));
//             break;
//           case "remove":
//             if (!i) return delete n[s.name], a;
//             var u = {};
//             return t.each(i.split(/\s/), function (t, e) {
//               u[e] = a[e], delete a[e]
//             }), u
//         }
//       }
//       var o = t.validator.normalizeRules(t.extend({}, t.validator.classRules(s), t.validator.attributeRules(s), t.validator.dataRules(s), t.validator.staticRules(s)), s);
//       if (o.required) {
//         var l = o.required;
//         delete o.required, o = t.extend({
//           required: l
//         }, o)
//       }
//       return o
//     }
//   }), t.extend(t.expr[":"], {
//     blank: function (e) {
//       return !t.trim("" + t(e).val())
//     },
//     filled: function (e) {
//       return !!t.trim("" + t(e).val())
//     },
//     unchecked: function (e) {
//       return !t(e).prop("checked")
//     }
//   }), t.validator = function (e, i) {
//     this.settings = t.extend(!0, {}, t.validator.defaults, e), this.currentForm = i, this.init()
//   }, t.validator.format = function (e, i) {
//     return 1 === arguments.length ? function () {
//       var i = t.makeArray(arguments);
//       return i.unshift(e), t.validator.format.apply(this, i)
//     } : (arguments.length > 2 && i.constructor !== Array && (i = t.makeArray(arguments).slice(1)), i.constructor !== Array && (i = [i]), t.each(i, function (t, i) {
//       e = e.replace(RegExp("\\{" + t + "\\}", "g"), function () {
//         return i
//       })
//     }), e)
//   }, t.extend(t.validator, {
//     defaults: {
//       messages: {},
//       groups: {},
//       rules: {},
//       errorClass: "error",
//       validClass: "valid",
//       errorElement: "label",
//       focusInvalid: !0,
//       errorContainer: t([]),
//       errorLabelContainer: t([]),
//       onsubmit: !0,
//       ignore: ":hidden",
//       ignoreTitle: !1,
//       onfocusin: function (t) {
//         this.lastActive = t, this.settings.focusCleanup && !this.blockFocusCleanup && (this.settings.unhighlight && this.settings.unhighlight.call(this, t, this.settings.errorClass, this.settings.validClass), this.addWrapper(this.errorsFor(t)).hide())
//       },
//       onfocusout: function (t) {
//         this.checkable(t) || !(t.name in this.submitted) && this.optional(t) || this.element(t)
//       },
//       onkeyup: function (t, e) {
//         (9 !== e.which || "" !== this.elementValue(t)) && (t.name in this.submitted || t === this.lastElement) && this.element(t)
//       },
//       onclick: function (t) {
//         t.name in this.submitted ? this.element(t) : t.parentNode.name in this.submitted && this.element(t.parentNode)
//       },
//       highlight: function (e, i, s) {
//         "radio" === e.type ? this.findByName(e.name).addClass(i).removeClass(s) : t(e).addClass(i).removeClass(s)
//       },
//       unhighlight: function (e, i, s) {
//         "radio" === e.type ? this.findByName(e.name).removeClass(i).addClass(s) : t(e).removeClass(i).addClass(s)
//       }
//     },
//     setDefaults: function (e) {
//       t.extend(t.validator.defaults, e)
//     },
//     messages: {
//       required: "This field is required.",
//       remote: "Please fix this field.",
//       email: "Please enter a valid email address.",
//       url: "Please enter a valid URL.",
//       date: "Please enter a valid date.",
//       dateISO: "Please enter a valid date (ISO).",
//       number: "Please enter a valid number.",
//       digits: "Please enter only digits.",
//       creditcard: "Please enter a valid credit card number.",
//       equalTo: "Please enter the same value again.",
//       maxlength: t.validator.format("Please enter no more than {0} characters."),
//       minlength: t.validator.format("Please enter at least {0} characters."),
//       rangelength: t.validator.format("Please enter a value between {0} and {1} characters long."),
//       range: t.validator.format("Please enter a value between {0} and {1}."),
//       max: t.validator.format("Please enter a value less than or equal to {0}."),
//       min: t.validator.format("Please enter a value greater than or equal to {0}.")
//     },
//     autoCreateRanges: !1,
//     prototype: {
//       init: function () {
//         function e(e) {
//           var i = t.data(this[0].form, "validator"),
//             s = "on" + e.type.replace(/^validate/, "");
//           i.settings[s] && i.settings[s].call(i, this[0], e)
//         }
//         this.labelContainer = t(this.settings.errorLabelContainer), this.errorContext = this.labelContainer.length && this.labelContainer || t(this.currentForm), this.containers = t(this.settings.errorContainer).add(this.settings.errorLabelContainer), this.submitted = {}, this.valueCache = {}, this.pendingRequest = 0, this.pending = {}, this.invalid = {}, this.reset();
//         var i = this.groups = {};
//         t.each(this.settings.groups, function (e, s) {
//           "string" == typeof s && (s = s.split(/\s/)), t.each(s, function (t, s) {
//             i[s] = e
//           })
//         });
//         var s = this.settings.rules;
//         t.each(s, function (e, i) {
//           s[e] = t.validator.normalizeRule(i)
//         }), t(this.currentForm).validateDelegate(":text, [type='password'], [type='file'], select, textarea, [type='number'], [type='search'] ,[type='tel'], [type='url'], [type='email'], [type='datetime'], [type='date'], [type='month'], [type='week'], [type='time'], [type='datetime-local'], [type='range'], [type='color'] ", "focusin focusout keyup", e).validateDelegate("[type='radio'], [type='checkbox'], select, option", "click", e), this.settings.invalidHandler && t(this.currentForm).bind("invalid-form.validate", this.settings.invalidHandler)
//       },
//       form: function () {
//         return this.checkForm(), t.extend(this.submitted, this.errorMap), this.invalid = t.extend({}, this.errorMap), this.valid() || t(this.currentForm).triggerHandler("invalid-form", [this]), this.showErrors(), this.valid()
//       },
//       checkForm: function () {
//         this.prepareForm();
//         for (var t = 0, e = this.currentElements = this.elements(); e[t]; t++) this.check(e[t]);
//         return this.valid()
//       },
//       element: function (e) {
//         e = this.validationTargetFor(this.clean(e)), this.lastElement = e, this.prepareElement(e), this.currentElements = t(e);
//         var i = this.check(e) !== !1;
//         return i ? delete this.invalid[e.name] : this.invalid[e.name] = !0, this.numberOfInvalids() || (this.toHide = this.toHide.add(this.containers)), this.showErrors(), i
//       },
//       showErrors: function (e) {
//         if (e) {
//           t.extend(this.errorMap, e), this.errorList = [];
//           for (var i in e) this.errorList.push({
//             message: e[i],
//             element: this.findByName(i)[0]
//           });
//           this.successList = t.grep(this.successList, function (t) {
//             return !(t.name in e)
//           })
//         }
//         this.settings.showErrors ? this.settings.showErrors.call(this, this.errorMap, this.errorList) : this.defaultShowErrors()
//       },
//       resetForm: function () {
//         t.fn.resetForm && t(this.currentForm).resetForm(), this.submitted = {}, this.lastElement = null, this.prepareForm(), this.hideErrors(), this.elements().removeClass(this.settings.errorClass).removeData("previousValue")
//       },
//       numberOfInvalids: function () {
//         return this.objectLength(this.invalid)
//       },
//       objectLength: function (t) {
//         var e = 0;
//         for (var i in t) e++;
//         return e
//       },
//       hideErrors: function () {
//         this.addWrapper(this.toHide).hide()
//       },
//       valid: function () {
//         return 0 === this.size()
//       },
//       size: function () {
//         return this.errorList.length
//       },
//       focusInvalid: function () {
//         if (this.settings.focusInvalid) try {
//           t(this.findLastActive() || this.errorList.length && this.errorList[0].element || []).filter(":visible").focus().trigger("focusin")
//         } catch (e) {}
//       },
//       findLastActive: function () {
//         var e = this.lastActive;
//         return e && 1 === t.grep(this.errorList, function (t) {
//           return t.element.name === e.name
//         }).length && e
//       },
//       elements: function () {
//         var e = this,
//           i = {};
//         return t(this.currentForm).find("input, select, textarea").not(":submit, :reset, :image, [disabled]").not(this.settings.ignore).filter(function () {
//           return !this.name && e.settings.debug && window.console && console.error("%o has no name assigned", this), this.name in i || !e.objectLength(t(this).rules()) ? !1 : (i[this.name] = !0, !0)
//         })
//       },
//       clean: function (e) {
//         return t(e)[0]
//       },
//       errors: function () {
//         var e = this.settings.errorClass.replace(" ", ".");
//         return t(this.settings.errorElement + "." + e, this.errorContext)
//       },
//       reset: function () {
//         this.successList = [], this.errorList = [], this.errorMap = {}, this.toShow = t([]), this.toHide = t([]), this.currentElements = t([])
//       },
//       prepareForm: function () {
//         this.reset(), this.toHide = this.errors().add(this.containers)
//       },
//       prepareElement: function (t) {
//         this.reset(), this.toHide = this.errorsFor(t)
//       },
//       elementValue: function (e) {
//         var i = t(e).attr("type"),
//           s = t(e).val();
//         return "radio" === i || "checkbox" === i ? t("input[name='" + t(e).attr("name") + "']:checked").val() : "string" == typeof s ? s.replace(/\r/g, "") : s
//       },
//       check: function (e) {
//         e = this.validationTargetFor(this.clean(e));
//         var i, s = t(e).rules(),
//           r = !1,
//           n = this.elementValue(e);
//         for (var a in s) {
//           var u = {
//             method: a,
//             parameters: s[a]
//           };
//           try {
//             if (i = t.validator.methods[a].call(this, n, e, u.parameters), "dependency-mismatch" === i) {
//               r = !0;
//               continue
//             }
//             if (r = !1, "pending" === i) return this.toHide = this.toHide.not(this.errorsFor(e)), void 0;
//             if (!i) return this.formatAndAdd(e, u), !1
//           } catch (o) {
//             throw this.settings.debug && window.console && console.log("Exception occurred when checking element " + e.id + ", check the '" + u.method + "' method.", o), o
//           }
//         }
//         return r ? void 0 : (this.objectLength(s) && this.successList.push(e), !0)
//       },
//       customDataMessage: function (e, i) {
//         return t(e).data("msg-" + i.toLowerCase()) || e.attributes && t(e).attr("data-msg-" + i.toLowerCase())
//       },
//       customMessage: function (t, e) {
//         var i = this.settings.messages[t];
//         return i && (i.constructor === String ? i : i[e])
//       },
//       findDefined: function () {
//         for (var t = 0; arguments.length > t; t++)
//           if (void 0 !== arguments[t]) return arguments[t];
//         return void 0
//       },
//       defaultMessage: function (e, i) {
//         return this.findDefined(this.customMessage(e.name, i), this.customDataMessage(e, i), !this.settings.ignoreTitle && e.title || void 0, t.validator.messages[i], "<strong>Warning: No message defined for " + e.name + "</strong>")
//       },
//       formatAndAdd: function (e, i) {
//         var s = this.defaultMessage(e, i.method),
//           r = /\$?\{(\d+)\}/g;
//         "function" == typeof s ? s = s.call(this, i.parameters, e) : r.test(s) && (s = t.validator.format(s.replace(r, "{$1}"), i.parameters)), this.errorList.push({
//           message: s,
//           element: e
//         }), this.errorMap[e.name] = s, this.submitted[e.name] = s
//       },
//       addWrapper: function (t) {
//         return this.settings.wrapper && (t = t.add(t.parent(this.settings.wrapper))), t
//       },
//       defaultShowErrors: function () {
//         var t, e;
//         for (t = 0; this.errorList[t]; t++) {
//           var i = this.errorList[t];
//           this.settings.highlight && this.settings.highlight.call(this, i.element, this.settings.errorClass, this.settings.validClass), this.showLabel(i.element, i.message)
//         }
//         if (this.errorList.length && (this.toShow = this.toShow.add(this.containers)), this.settings.success)
//           for (t = 0; this.successList[t]; t++) this.showLabel(this.successList[t]);
//         if (this.settings.unhighlight)
//           for (t = 0, e = this.validElements(); e[t]; t++) this.settings.unhighlight.call(this, e[t], this.settings.errorClass, this.settings.validClass);
//         this.toHide = this.toHide.not(this.toShow), this.hideErrors(), this.addWrapper(this.toShow).show()
//       },
//       validElements: function () {
//         return this.currentElements.not(this.invalidElements())
//       },
//       invalidElements: function () {
//         return t(this.errorList).map(function () {
//           return this.element
//         })
//       },
//       showLabel: function (e, i) {
//         var s = this.errorsFor(e);
//         s.length ? (s.removeClass(this.settings.validClass).addClass(this.settings.errorClass), s.html(i)) : (s = t("<" + this.settings.errorElement + ">").attr("for", this.idOrName(e)).addClass(this.settings.errorClass).html(i || ""), this.settings.wrapper && (s = s.hide().show().wrap("<" + this.settings.wrapper + "/>").parent()), this.labelContainer.append(s).length || (this.settings.errorPlacement ? this.settings.errorPlacement(s, t(e)) : s.insertAfter(e))), !i && this.settings.success && (s.text(""), "string" == typeof this.settings.success ? s.addClass(this.settings.success) : this.settings.success(s, e)), this.toShow = this.toShow.add(s)
//       },
//       errorsFor: function (e) {
//         var i = this.idOrName(e);
//         return this.errors().filter(function () {
//           return t(this).attr("for") === i
//         })
//       },
//       idOrName: function (t) {
//         return this.groups[t.name] || (this.checkable(t) ? t.name : t.id || t.name)
//       },
//       validationTargetFor: function (t) {
//         return this.checkable(t) && (t = this.findByName(t.name).not(this.settings.ignore)[0]), t
//       },
//       checkable: function (t) {
//         return /radio|checkbox/i.test(t.type)
//       },
//       findByName: function (e) {
//         return t(this.currentForm).find("[name='" + e + "']")
//       },
//       getLength: function (e, i) {
//         switch (i.nodeName.toLowerCase()) {
//           case "select":
//             return t("option:selected", i).length;
//           case "input":
//             if (this.checkable(i)) return this.findByName(i.name).filter(":checked").length
//         }
//         return e.length
//       },
//       depend: function (t, e) {
//         return this.dependTypes[typeof t] ? this.dependTypes[typeof t](t, e) : !0
//       },
//       dependTypes: {
//         "boolean": function (t) {
//           return t
//         },
//         string: function (e, i) {
//           return !!t(e, i.form).length
//         },
//         "function": function (t, e) {
//           return t(e)
//         }
//       },
//       optional: function (e) {
//         var i = this.elementValue(e);
//         return !t.validator.methods.required.call(this, i, e) && "dependency-mismatch"
//       },
//       startRequest: function (t) {
//         this.pending[t.name] || (this.pendingRequest++, this.pending[t.name] = !0)
//       },
//       stopRequest: function (e, i) {
//         this.pendingRequest--, 0 > this.pendingRequest && (this.pendingRequest = 0), delete this.pending[e.name], i && 0 === this.pendingRequest && this.formSubmitted && this.form() ? (t(this.currentForm).submit(), this.formSubmitted = !1) : !i && 0 === this.pendingRequest && this.formSubmitted && (t(this.currentForm).triggerHandler("invalid-form", [this]), this.formSubmitted = !1)
//       },
//       previousValue: function (e) {
//         return t.data(e, "previousValue") || t.data(e, "previousValue", {
//           old: null,
//           valid: !0,
//           message: this.defaultMessage(e, "remote")
//         })
//       }
//     },
//     classRuleSettings: {
//       required: {
//         required: !0
//       },
//       email: {
//         email: !0
//       },
//       url: {
//         url: !0
//       },
//       date: {
//         date: !0
//       },
//       dateISO: {
//         dateISO: !0
//       },
//       number: {
//         number: !0
//       },
//       digits: {
//         digits: !0
//       },
//       creditcard: {
//         creditcard: !0
//       }
//     },
//     addClassRules: function (e, i) {
//       e.constructor === String ? this.classRuleSettings[e] = i : t.extend(this.classRuleSettings, e)
//     },
//     classRules: function (e) {
//       var i = {},
//         s = t(e).attr("class");
//       return s && t.each(s.split(" "), function () {
//         this in t.validator.classRuleSettings && t.extend(i, t.validator.classRuleSettings[this])
//       }), i
//     },
//     attributeRules: function (e) {
//       var i = {},
//         s = t(e),
//         r = s[0].getAttribute("type");
//       for (var n in t.validator.methods) {
//         var a;
//         "required" === n ? (a = s.get(0).getAttribute(n), "" === a && (a = !0), a = !!a) : a = s.attr(n), /min|max/.test(n) && (null === r || /number|range|text/.test(r)) && (a = Number(a)), a ? i[n] = a : r === n && "range" !== r && (i[n] = !0)
//       }
//       return i.maxlength && /-1|2147483647|524288/.test(i.maxlength) && delete i.maxlength, i
//     },
//     dataRules: function (e) {
//       var i, s, r = {},
//         n = t(e);
//       for (i in t.validator.methods) s = n.data("rule-" + i.toLowerCase()), void 0 !== s && (r[i] = s);
//       return r
//     },
//     staticRules: function (e) {
//       var i = {},
//         s = t.data(e.form, "validator");
//       return s.settings.rules && (i = t.validator.normalizeRule(s.settings.rules[e.name]) || {}), i
//     },
//     normalizeRules: function (e, i) {
//       return t.each(e, function (s, r) {
//         if (r === !1) return delete e[s], void 0;
//         if (r.param || r.depends) {
//           var n = !0;
//           switch (typeof r.depends) {
//             case "string":
//               n = !!t(r.depends, i.form).length;
//               break;
//             case "function":
//               n = r.depends.call(i, i)
//           }
//           n ? e[s] = void 0 !== r.param ? r.param : !0 : delete e[s]
//         }
//       }), t.each(e, function (s, r) {
//         e[s] = t.isFunction(r) ? r(i) : r
//       }), t.each(["minlength", "maxlength"], function () {
//         e[this] && (e[this] = Number(e[this]))
//       }), t.each(["rangelength", "range"], function () {
//         var i;
//         e[this] && (t.isArray(e[this]) ? e[this] = [Number(e[this][0]), Number(e[this][1])] : "string" == typeof e[this] && (i = e[this].split(/[\s,]+/), e[this] = [Number(i[0]), Number(i[1])]))
//       }), t.validator.autoCreateRanges && (e.min && e.max && (e.range = [e.min, e.max], delete e.min, delete e.max), e.minlength && e.maxlength && (e.rangelength = [e.minlength, e.maxlength], delete e.minlength, delete e.maxlength)), e
//     },
//     normalizeRule: function (e) {
//       if ("string" == typeof e) {
//         var i = {};
//         t.each(e.split(/\s/), function () {
//           i[this] = !0
//         }), e = i
//       }
//       return e
//     },
//     addMethod: function (e, i, s) {
//       t.validator.methods[e] = i, t.validator.messages[e] = void 0 !== s ? s : t.validator.messages[e], 3 > i.length && t.validator.addClassRules(e, t.validator.normalizeRule(e))
//     },
//     methods: {
//       required: function (e, i, s) {
//         if (!this.depend(s, i)) return "dependency-mismatch";
//         if ("select" === i.nodeName.toLowerCase()) {
//           var r = t(i).val();
//           return r && r.length > 0
//         }
//         return this.checkable(i) ? this.getLength(e, i) > 0 : t.trim(e).length > 0
//       },
//       email: function (t, e) {
//         return this.optional(e) || /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i.test(t)
//       },
//       url: function (t, e) {
//         return this.optional(e) || /^(https?|s?ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(t)
//       },
//       date: function (t, e) {
//         return this.optional(e) || !/Invalid|NaN/.test("" + new Date(t))
//       },
//       dateISO: function (t, e) {
//         return this.optional(e) || /^\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}$/.test(t)
//       },
//       number: function (t, e) {
//         return this.optional(e) || /^-?(?:\d+|\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test(t)
//       },
//       digits: function (t, e) {
//         return this.optional(e) || /^\d+$/.test(t)
//       },
//       creditcard: function (t, e) {
//         if (this.optional(e)) return "dependency-mismatch";
//         if (/[^0-9 \-]+/.test(t)) return !1;
//         var i = 0,
//           s = 0,
//           r = !1;
//         t = t.replace(/\D/g, "");
//         for (var n = t.length - 1; n >= 0; n--) {
//           var a = t.charAt(n);
//           s = parseInt(a, 10), r && (s *= 2) > 9 && (s -= 9), i += s, r = !r
//         }
//         return 0 === i % 10
//       },
//       minlength: function (e, i, s) {
//         var r = t.isArray(e) ? e.length : this.getLength(t.trim(e), i);
//         return this.optional(i) || r >= s
//       },
//       maxlength: function (e, i, s) {
//         var r = t.isArray(e) ? e.length : this.getLength(t.trim(e), i);
//         return this.optional(i) || s >= r
//       },
//       rangelength: function (e, i, s) {
//         var r = t.isArray(e) ? e.length : this.getLength(t.trim(e), i);
//         return this.optional(i) || r >= s[0] && s[1] >= r
//       },
//       min: function (t, e, i) {
//         return this.optional(e) || t >= i
//       },
//       max: function (t, e, i) {
//         return this.optional(e) || i >= t
//       },
//       range: function (t, e, i) {
//         return this.optional(e) || t >= i[0] && i[1] >= t
//       },
//       equalTo: function (e, i, s) {
//         var r = t(s);
//         return this.settings.onfocusout && r.unbind(".validate-equalTo").bind("blur.validate-equalTo", function () {
//           t(i).valid()
//         }), e === r.val()
//       },
//       remote: function (e, i, s) {
//         if (this.optional(i)) return "dependency-mismatch";
//         var r = this.previousValue(i);
//         if (this.settings.messages[i.name] || (this.settings.messages[i.name] = {}), r.originalMessage = this.settings.messages[i.name].remote, this.settings.messages[i.name].remote = r.message, s = "string" == typeof s && {
//             url: s
//           } || s, r.old === e) return r.valid;
//         r.old = e;
//         var n = this;
//         this.startRequest(i);
//         var a = {};
//         return a[i.name] = e, t.ajax(t.extend(!0, {
//           url: s,
//           mode: "abort",
//           port: "validate" + i.name,
//           dataType: "json",
//           data: a,
//           success: function (s) {
//             n.settings.messages[i.name].remote = r.originalMessage;
//             var a = s === !0 || "true" === s;
//             if (a) {
//               var u = n.formSubmitted;
//               n.prepareElement(i), n.formSubmitted = u, n.successList.push(i), delete n.invalid[i.name], n.showErrors()
//             } else {
//               var o = {},
//                 l = s || n.defaultMessage(i, "remote");
//               o[i.name] = r.message = t.isFunction(l) ? l(e) : l, n.invalid[i.name] = !0, n.showErrors(o)
//             }
//             r.valid = a, n.stopRequest(i, a)
//           }
//         }, s)), "pending"
//       }
//     }
//   }), t.format = t.validator.format
// })(jQuery),
// function (t) {
//   var e = {};
//   if (t.ajaxPrefilter) t.ajaxPrefilter(function (t, i, s) {
//     var r = t.port;
//     "abort" === t.mode && (e[r] && e[r].abort(), e[r] = s)
//   });
//   else {
//     var i = t.ajax;
//     t.ajax = function (s) {
//       var r = ("mode" in s ? s : t.ajaxSettings).mode,
//         n = ("port" in s ? s : t.ajaxSettings).port;
//       return "abort" === r ? (e[n] && e[n].abort(), e[n] = i.apply(this, arguments), e[n]) : i.apply(this, arguments)
//     }
//   }
// }(jQuery),
// function (t) {
//   t.extend(t.fn, {
//     validateDelegate: function (e, i, s) {
//       return this.bind(i, function (i) {
//         var r = t(i.target);
//         return r.is(e) ? s.apply(r, arguments) : void 0
//       })
//     }
//   })
// }(jQuery);
